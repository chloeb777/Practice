class Vector {
  float x, y;
  Vector(float x_, float y_) {
    x = x_;
    y = y_;
  }
  void add(Vector v_) {
    x += v_.x;
    y += v_.y;
  }
  void sub(Vector v_) {
    x -= v_.x;
    y -= v_.y;
  }
  void mult(float n) {
    x *= n;
    y *= n;
  }
  void div(float n) {
    if (n != 0.0) {
      x /= n;
      y /= n;
    }
  }
  float mag() {
    return (float) Math.sqrt(x*x + y*y);
  }
  void normalize() {
    float m = mag();
    if (m != 0) {
      div(m);
    }
  }
  void setMag(float s) {
    normalize();
    mult(s);
  }
}
