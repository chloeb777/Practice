class Ball{
  Vector loc;
  Vector vel;
  int xSz, ySz, colorIntr,colorIntg,colorIntb;
  Ball(float x_, float y_) {
      loc = new Vector(x_,y_);
      vel = new Vector(1,0);
      xSz = ySz = 50;

  }
  
  void move() {
    loc.add(vel);
  }
}
