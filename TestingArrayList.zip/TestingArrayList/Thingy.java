class Thingy
{
  private int myNum;
  public Thingy(int nSome_)
  {
    myNum = nSome_;
  }
  public int getNum()
  {
    return myNum;
  }
  
}  
